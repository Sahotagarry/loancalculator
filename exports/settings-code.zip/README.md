# Settings area — reusable code from the Clearline Loan Calculator

This bundle contains the code behind the Settings page that stores Azure
credentials (Document Intelligence, OpenAI) and the Blob Storage connection
string, encrypted at rest in a Postgres table.

## What's in here

server/
  azure-settings.ts   The core of the feature. Load/save settings with
                      AES-256-GCM encryption keyed from the SESSION_SECRET
                      environment variable. Env vars act as a fallback when
                      no value is saved in the database. Refuses to save
                      secrets unencrypted if SESSION_SECRET is missing.
  admin-auth.ts       Password unlock for the Settings page: exchanges the
                      admin password for a short-lived token; requireAdmin
                      middleware protects the settings routes.
  settings.ts         The Express routes: POST /settings/unlock,
                      GET/PUT /settings/azure. Note the GET never returns
                      saved keys — only "is set" flags — so secrets never
                      travel back to the browser.

db/
  settings-schema.ts  The app_settings table (Drizzle ORM): a simple
                      key/value store with an updated_at timestamp.
                      Equivalent raw SQL:
                        CREATE TABLE app_settings (
                          key text PRIMARY KEY,
                          value text NOT NULL,
                          updated_at timestamptz NOT NULL DEFAULT now()
                        );

client/
  settings-page.tsx   The React settings page (unlock form, masked key
                      inputs, save/clear behavior).

## How to reuse in another app

1. Create the app_settings table (SQL above, or the Drizzle schema).
2. Copy server/azure-settings.ts and adjust two things for your app:
   - AZURE_SETTING_KEYS: rename/add/remove the settings your app needs
     (each entry maps a field to a database key and an env-var fallback).
   - The import of your database client (`db`, `appSettingsTable`).
3. Copy the routes and admin-auth if you want the same password-unlock
   flow, or protect the routes with whatever auth your other app uses.
4. Set a SESSION_SECRET environment variable on the server (any long
   random string). Keep it stable — changing it makes previously saved
   values unreadable and they must be re-entered.
5. The client page uses this project's UI kit (shadcn/ui) and generated
   API hooks; treat it as a reference rather than a drop-in file.

## Key design points worth keeping

- Secrets are encrypted before they hit the database (AES-256-GCM,
  key derived from SESSION_SECRET via scrypt).
- The API never returns saved secrets, only whether they are set.
- Clearing a field deletes the row so the env-var fallback applies again.
- Saving fails loudly (HTTP 503) instead of silently storing plain text
  when SESSION_SECRET is not configured.
